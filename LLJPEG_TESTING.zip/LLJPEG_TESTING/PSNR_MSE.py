# -*- coding: utf-8 -*-
"""
Created on Thu Apr 19 23:48:59 2018

@author: Administrator
"""
from PIL import Image
import numpy as np
from skimage.measure import compare_mse
from skimage.measure import compare_psnr

  

A = np.array(Image.open('2.jpg'))
B = np.array(Image.open('1.jpg'))
err = compare_mse(A, B)
psnr = compare_psnr(A, B)
print(err)  
print(psnr)